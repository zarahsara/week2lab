// ITERATION 1

// Suspects Array

const suspectsArray = [];







































// Rooms Array

const roomsArray = [];

// Weapons Array

const weaponsArray = [];


// ITERATION 2

function selectRandom() {}

function pickMystery() {}


// ITERATION 3

function revealMystery() {}



// The following is required to make unit tests work.
/* Environment setup. Do not modify the below code. */
if (typeof module !== 'undefined') {
  module.exports = {
    suspectsArray,
    roomsArray,
    weaponsArray,
    pickMystery,
    revealMystery,
    selectRandom
  };
}
